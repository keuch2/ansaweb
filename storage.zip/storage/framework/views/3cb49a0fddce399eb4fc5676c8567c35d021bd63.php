<?php $__env->startSection('main-content'); ?>

    <main class="main">

        <div class="home-top-container">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner banner-image">
                            <a href="#">
                                <img src="front/img/mra.jpg" alt="banner">
                            </a>
                        </div><!-- End .banner -->
                    </div><!-- End .col-lg-5 -->
                </div><!-- End .row -->
            </div><!-- End .container -->
        </div><!-- End .home-top-container -->

        <!-- BUSCADOR -->
        <?php echo $__env->make('parts.home_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- END BUSCADOR -->

        <div class="mb-5"></div><!-- margin -->

        <?php if(isset($featured)): ?>
            <?php if(count($featured) > 0): ?>
                <!-- DESTACADOS -->
                <div class="container">
                    <h2 class="subtitle">
                        <span>Neumáticos Destacados</span>
                    </h2>

                    <div class="featured-products owl-carousel owl-theme owl-nav-top">
                        <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $GsPrice = ($ft->final_price) * $dolarToGs;
                                $RealPrice = ($ft->final_price) * $dolarToReal;
                            ?>

                            <div class="product">
                                <figure class="product-image-container">
                                    <a href="<?php echo e(route('tire-byId', ['tireId'=>$ft->id])); ?>" class="product-image">
                                        <img src="<?php echo e(url($ft->photo)); ?>" alt="neumatico">
                                    </a>
                                </figure>
                                <div class="product-details">
                                    <div class="ratings-container">
                                    </div><!-- End .product-container -->
                                    <h2 class="product-title">
                                        <a href="<?php echo e(route('tire-byId', ['tireId'=>$ft->id])); ?>">Neumático <?php echo e($ft->brand->brand_name); ?></a>
                                    </h2>
                                    <div class="price-box">
                                        <span class="product-price">Gs. <?php echo e(number_format($GsPrice, 0, ',', '.')); ?></span>
                                        <span class="othercurrencies">RS$ <?php echo e(number_format($RealPrice, 2, ',', '.')); ?>  /  US$ <?php echo e(number_format($ft->final_price, 2, ',', '.')); ?></span>
                                    </div><!-- End .price-box -->
                                    <div class="product-action">
                                        <!-- <a href="product.html" class="paction add-cart" title="Add to Cart">
                                            <span>Agregar al Carrito</span>
                                        </a> -->
                                    </div><!-- End .product-action -->
                                </div><!-- End .product-details -->
                            </div><!-- End .product -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!-- End .featured-products -->

                </div><!-- End .container -->
                <!-- END DESTACADOS -->
            <?php endif; ?>
        <?php endif; ?>

        <div class="mb-5"></div><!-- margin -->

        <?php if(isset($promotions)): ?>
            <?php if(count($promotions) > 0): ?>
                <!-- PROMOCIONES -->
                <div class="banners-section">
                    <div class="container">
                        <h2 class="subtitle text-center"><span>Promociones</span></h2>
                        <div class="cats-carousel owl-carousel owl-theme">
                            <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="banner banner-image">
                                    <a href="#">
                                        <img src="<?php echo e(url($promotion->photo)); ?>" alt="promotion">
                                    </a>
                                </div><!-- End .banner -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!-- End .cat-carousel -->
                    </div><!-- End .container -->
                </div><!-- End .banners-section -->
                <!-- END PROMOCIONES -->
            <?php endif; ?>
        <?php endif; ?>

        <div class="mb-5"></div><!-- margin -->
        <?php if(isset($brands)): ?>
            <?php if(count($brands) > 0): ?>
                <!-- NUESTRAS MARCAS -->
                <div class="partners-container">
                    <div class="container">
                        <h2 class="subtitle">
                            <span>Nuestras Marcas</span>
                        </h2>
                        <div class="partners-carousel owl-carousel owl-theme">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="#" class="partner">
                                    <img src="<?php echo e(url($brand->photo)); ?>" alt="logo">
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div><!-- End .partners-carousel -->
                    </div><!-- End .container -->
                </div><!-- End .partners-container -->
                <!-- END NUESTRAS MARCAS -->
            <?php endif; ?>
        <?php endif; ?>

        <div class="mb-5"></div><!-- margin -->

        <?php if(isset($offers)): ?>
            <?php if(count($offers) > 0): ?>
                <!-- OFERTAS -->
                <div class="container arrived-products">
                    <h2 class="subtitle">
                        <span>Ofertas</span>
                    </h2>

                    <div class="row">
                        <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $GsPrice = ($offer->final_price) * $dolarToGs;
                                $RealPrice = ($offer->final_price) * $dolarToReal;
                                $GsOldPrice = ($offer->price) * $dolarToGs;
                            ?>

                            <div class="col-6 col-md-4 col-lg-3 col-xl-2">
                            <div class="product product-overlay">
                                <figure class="product-image-container">
                                    <a href="<?php echo e(route('tire-byId', ['tireId'=>$offer->id])); ?>" class="product-image">
                                        <img src="<?php echo e(url($offer->photo)); ?>" alt="neumatico">
                                    </a>
                                    <span class="product-label label-sale"><?php echo e(number_format($offer->discount_rate, 0, ',', '.')); ?> % OFF</span>
                                    <div class="product-action">
                                        <!-- <a href="product.html" class="paction add-cart" title="Add to Cart">
                                            <span>Agregar al Carrito</span>
                                        </a> -->
                                    </div><!-- End .product-action -->
                                </figure>
                                <div class="product-details">
                                    <div class="ratings-container">
                                    </div><!-- End .product-container -->
                                    <h2 class="product-title">
                                        <a href="<?php echo e(route('tire-byId', ['tireId'=>$offer->id])); ?>">Neumático <?php echo e($offer->brand->brand_name); ?></a>
                                    </h2>
                                    <div class="price-box">
                                        <span class="old-price">Gs. <?php echo e(number_format($GsOldPrice, 0, ',', '.')); ?></span>
                                        <span class="product-price">Gs. <?php echo e(number_format($GsPrice, 0, ',', '.')); ?></span>
                                        <span class="othercurrencies">RS$ <?php echo e(number_format($RealPrice, 2, ',', '.')); ?>  /  US$ <?php echo e(number_format($ft->final_price, 2, ',', '.')); ?></span>
                                    </div><!-- End .price-box -->

                                </div><!-- End .product-details -->
                            </div><!-- End .product -->
                        </div><!-- End .col-xl-2 -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div><!-- End .row -->
                </div><!-- End .container -->
                <!-- END OFERTAS -->
            <?php endif; ?>
        <?php endif; ?>

        <div class="mb-5"></div><!-- margin -->


    </main><!-- End .main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>