<?php $__env->startSection('main-content'); ?>


    <main class="main">
        <div class="banner banner-cat">
            <div class="banner-content container">
                <h1 class="banner-title">
                    Resultados de Busqueda
                </h1>
            </div><!-- End .banner-content -->
        </div><!-- End .banner -->

        <nav aria-label="breadcrumb" class="breadcrumb-nav">
            <div class="container">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item"><a href="#">Busqueda</a></li>
                </ol>
            </div><!-- End .container -->
        </nav>

        <div class="container">
            <nav class="toolbox">


                <div class="toolbox-item toolbox-show">
                    <label>Mostrando 1–12 de 60 resultados</label>
                </div><!-- End .toolbox-item -->


            </nav>

            <div class="product-wrapper">
                <div class="row row-sm category-grid">

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="othercurrencies">RS$ 2039  /  US$ 938</span>
                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="product-price">Gs. 350.000</span><span class="othercurrencies">RS$ 2039  /  US$ 938</span>

                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="product-price">Gs. 350.000</span><span class="othercurrencies">RS$ 2039  /  US$ 938</span>

                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="product-price">Gs. 350.000</span><span class="othercurrencies">RS$ 2039  /  US$ 938</span>

                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->

                    <div class="col-6 col-md-4 col-xl-3">
                        <div class="grid-product">
                            <figure class="product-image-container">
                                <a href="product.html" class="product-image">
                                    <img src="img/neumatico.jpg" alt="product">
                                </a>
                            </figure>
                            <div class="product-details">
                                <h2 class="product-title">
                                    <a href="product.html">Neumático</a>
                                </h2>
                                <div class="price-box">
                                    <span class="product-price">Gs. 350.000</span>
                                    <span class="product-price">Gs. 350.000</span><span class="othercurrencies">RS$ 2039  /  US$ 938</span>

                                </div><!-- End .price-box -->
                                <!-- <div class="product-grid-action">
                                        <a href="product.html" class="paction add-cart" title="Add to Cart">
                                        <span>Agregar al Carrito</span>
                                    </a>
                                </div> --><!-- End .product-action -->
                            </div><!-- End .product-details -->
                        </div><!-- End .product -->
                    </div><!-- End .col-xl-3 -->






                </div><!-- End .row -->
            </div>
            <nav class="toolbox toolbox-pagination">
                <div class="toolbox-item toolbox-show">
                    <label>Mostrando 1–12 de 60 resultados</label>
                </div><!-- End .toolbox-item -->

                <ul class="pagination">
                    <li class="page-item disabled">
                        <a class="page-link page-link-btn" href="#"><i class="icon-angle-left"></i></a>
                    </li>
                    <li class="page-item active">
                        <a class="page-link" href="#">1 <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">4</a></li>
                    <li class="page-item"><span>...</span></li>
                    <li class="page-item"><a class="page-link" href="#">15</a></li>
                    <li class="page-item">
                        <a class="page-link page-link-btn" href="#"><i class="icon-angle-right"></i></a>
                    </li>
                </ul>
            </nav>
        </div><!-- End .container -->

        <div class="mb-5"></div><!-- margin -->
    </main><!-- End .main -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontlayout.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>