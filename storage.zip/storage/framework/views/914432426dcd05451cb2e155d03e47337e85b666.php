<div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

<div class="mobile-menu-container">
    <div class="mobile-menu-wrapper">
        <span class="mobile-menu-close"><i class="icon-cancel"></i></span>
        <nav class="mobile-nav">
            <ul class="mobile-menu">
                <li><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                <li>
                    <a href="#" class="sf-with-ul">Productos</a>

                    <ul>
                        <li>
                            <a href="#" class="sf-with-ul">Neumáticos</a>

                            <ul>
                                <li><a href="#">Por tipo de vehículo</a>
                                    <!-- tipos de vehiculos -->
                                    <ul>
                                        <?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('tires-list-byVehicleType', ['vehicleTypeId' => $vehicleType->id])); ?>"><?php echo e($vehicleType->vehicle_type); ?></a></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li><a href="#">Por Marca</a>
                                    <!-- marcas de neumaticos -->
                                    <ul>
                                        <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('tires-list-byBrand', ['brandId' => $brand->id])); ?>"><?php echo e($brand->brand_name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>

                                <li><a href="<?php echo e(route('tires-list')); ?>">Todos</a></li>
                            </ul>
                        </li>

                        <li>
                            <a href="#" class="sf-with-ul">Productos</a>
                            <ul>
                                <li><a href="#">Categorías</a>
                                    <!-- categorias de productos -->
                                    <ul>
                                        <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('products-list-byProductCategory', ['productCategoryId' => $productCategory->id])); ?>"><?php echo e($productCategory->category_name); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                            </ul>
                        </li>

                    </ul>
                </li>
                <li><a href="#">Servicios</a></li>
                <li><a href="<?php echo e(route('static-branchoffices')); ?>">Sucursales</a></li>
                <li><a href="<?php echo e(route('static-aboutus')); ?>">Acerca de ANSA</a></li>
            </ul>
        </nav><!-- End .mobile-nav -->

        <div class="social-icons">
            <a href="#" class="social-icon" target="_blank"><i class="icon-facebook"></i></a>
            <a href="#" class="social-icon" target="_blank"><i class="icon-instagram"></i></a>
        </div><!-- End .social-icons -->
    </div><!-- End .mobile-menu-wrapper -->
</div><!-- End .mobile-menu-container -->