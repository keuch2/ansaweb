<div class="header-top">
    <div class="container">

        <div class="header-left header-dropdowns">
            <div style="padding-right: 20px;color:#000;">SELECCIONAR DIVISA</div>
            <div class="header-dropdown">
                <a href="#">GUARANIES</a>
                <div class="header-menu">
                    <ul>
                        <li><a href="#">GUARANIES</a></li>
                        <li><a href="#">REALES</a></li>
                        <li><a href="#">DOLARES</a></li>
                    </ul>
                </div><!-- End .header-menu -->
            </div><!-- End .header-dropown -->
        </div><!-- End .header-left -->

        <div class="header-right">
            <p class="welcome-msg">Bienvenido Rudi!</p>

            <div class="header-dropdown dropdown-expanded">
                <a href="#">Links</a>
                <div class="header-menu">
                    <ul>
                        <li><a href="my-account.html">MI CUENTA </a></li>
                        <li><a href="contact.html">CONTACTENOS</a></li>
                        <li><a href="#" class="login-link">LOG IN</a></li>
                    </ul>
                </div><!-- End .header-menu -->
            </div><!-- End .header-dropown -->
        </div><!-- End .header-right -->
    </div><!-- End .container -->
</div><!-- End .header-top -->