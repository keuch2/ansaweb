<div class="header-top">
    <div class="container">

        
    </div><!-- End .container -->
</div><!-- End .header-top -->