<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>América Neumáticos S.A. - ANSA</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/front/assets/images/icons/favicon_ansa.png">

    <!-- Plugins CSS File -->
    <link rel="stylesheet" href="/front/assets/css/bootstrap.min.css">

    <!-- Main CSS File -->
    <link rel="stylesheet" href="/front/assets/css/style.min.css">

    <?php echo $__env->yieldContent('header_scripts'); ?>
</head>
<body>
<div class="page-wrapper">
    <header class="header">
        <?php echo $__env->make('includes.header-top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('includes.header-middle', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header><!-- End .header -->

    <?php echo $__env->yieldContent('main-content'); ?>

</div><!-- End .page-wrapper -->

<?php echo $__env->make('includes.header-mobile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<a id="scroll-top" href="#top" title="Top" role="button"><i class="icon-angle-up"></i></a>

<!-- Plugins JS File -->
<script src="/front/assets/js/jquery.min.js"></script>
<script src="/front/assets/js/bootstrap.bundle.min.js"></script>
<script src="/front/assets/js/plugins.min.js"></script>

<!-- Main JS File -->
<script src="/front/assets/js/main.min.js"></script>

<?php echo $__env->yieldContent('footer_scripts'); ?>

<script>

    function setCurrency(cid)
    {
        var token = $("input[name='_token']").val();
        $.ajax({
            url: "<?php echo route('setcurrency-ajax')?>",
            method: 'POST',
            data: {
                currencyId: cid,
                _token:token
            },
            success: function(data) {
                //alert('success:  '+ data.currency_label);
                $("#current_currency").html(data.currency_label);

            },
            error: function(e){
                //alert('error ' + JSON.stringify(e) )
                Console.log('error ' + JSON.stringify(e));
            }
        });
    }

</script>

</body>
</html>